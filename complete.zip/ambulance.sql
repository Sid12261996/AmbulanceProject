-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 11, 2018 at 01:32 PM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ambulance`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambulanceinfo`
--

CREATE TABLE IF NOT EXISTS `ambulanceinfo` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `userPhone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ambulanceinfo`
--

INSERT INTO `ambulanceinfo` (`fname`, `lname`, `userPhone`, `email`, `pass`, `word`) VALUES
('Shekhar', 'saini', '0965085111', 'sainishekhar1414@gmail.com', '', '1414'),
('Shekhar', 'saini', '9650855090', 'sainishekhar581@gmail.com', 'asdfg', 'asdfg'),
('Shekhar', 'saini', '', 'sainishekhar81@gmail.com', '1234', '1234'),
('Shekhar', 'saini', '0965085500', 'sainishekhar@gmail.com', '1234', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `hospitalinfo`
--

CREATE TABLE IF NOT EXISTS `hospitalinfo` (
  `fname` varchar(10) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `word` varchar(20) NOT NULL,
  UNIQUE KEY `fname` (`fname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `fname` char(15) NOT NULL,
  `lname` char(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `bdays` date NOT NULL,
  `userPhone` decimal(10,0) NOT NULL,
  `pass` varchar(16) NOT NULL,
  `word` varchar(16) NOT NULL,
  UNIQUE KEY `userPhone` (`userPhone`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`fname`, `lname`, `email`, `bdays`, `userPhone`, `pass`, `word`) VALUES
('Shekhar', 'saini', 'sainishekhar586661@gmail.com', '0000-00-00', 0, '', '666'),
('Shekhar', 'saini', 'sainishekhar584521@gmail.com', '0000-00-00', 965085423, '2424', '2424'),
('Shekhar', 'saini', 'sainishekhar581@gmail.com', '2018-11-07', 9650855090, 'saini1998@', 'saini1998@'),
('Shekhar', 'saini', 'sainishekh5ar581@gmail.com', '2018-11-01', 9650855097, '1111', '1111');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
