
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>SignUp Form</title>
		<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="loginbox">
		<img src="Img/user.jpg" class="avatar">
			<h1><u>SIGNUP HERE</u></h1>

			<form method="POST" action="">
			
			

				<p>Hospital Refrence ID</p>
				<input type="text" name="fname" placeholder="Enter Reference ID" value=""/>

				<p>Password</p>
				<input type="password" name="pass" placeholder="Enter Password" value=""/>

				<p>Confirm Password</p>
				<input type="password" name="word" placeholder="Confirmed Password" value=""/>
				<input type="submit" name="signup" value="SignUp"/>

				<small>Already have an account? </small><a href="LoginHos.php"><u>LogIn Here</u></a>
			</form>
	</div>

</body>
</html>
<?php
$fname=$pass=$word="";
if(isset($_POST['signup']))
        {
					$fname=$_POST['fname'];
					$pass=$_POST['pass'];
					$word=$_POST['word'];
			
            
            if($fname=="" && $pass=="" && $word=="")
			echo '<script>alert("all fields are required")</script>';
						
            else
                {
					
					$con=mysql_connect('localhost','root','') or die(mysql_error());  
					mysql_select_db('ambulance') or die("cannot select DB");  
  					$query="INSERT INTO hospitalinfo(fname,pass,word)values('".$fname."','".$pass."','".$word."')";

                    $result=mysql_query($query) or die(mysql_error());
                    {
                        if($result>0)
                        {echo '<script>alert("You have successfully signup")</script>';
						}  
                    }
                }    
        }
?>