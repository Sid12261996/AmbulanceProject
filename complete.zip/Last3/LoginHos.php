<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>LogIn Form</title>
		<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div class="loginbox">
		<img src="Img/user.jpg" class="avatar">
			<h1><u>LOGIN HERE</u></h1>

			<form method="post" action="">
				<p>Hospital Refrence ID</p>
				<input type="text" name="fname" placeholder="Enter Reference ID">
				<p>Password</p>
				<input type="password" name="pass" placeholder="Enter Password"/><br><br>
				<button type="submit" name="login" >LogIn</button><br><br>
				<small>Don't have an account? </small><br><a href="SignupHos.php"><u>SignUp Here</u></a>
			</form>

	</div>
</body>
</html>

<?php  
if(isset($_POST["login"])){  
  
if(!empty($_POST['fname']) && !empty($_POST['pass'])) {  
    $fname=$_POST['fname'];  
    $pass=$_POST['pass'];  
  
    $con=mysql_connect('localhost','root','') or die(mysql_error());  
    mysql_select_db('ambulance') or die("cannot select DB");  
  
    $query=mysql_query("SELECT * FROM hospitalinfo WHERE fname='".$fname."' AND pass='".$pass."'");  
    $numrows=mysql_num_rows($query);  
    if($numrows!=0)  
    {  
    while($row=mysql_fetch_assoc($query))  
    {  
    $dbfname=$row['fname'];  
    $dbpass=$row['pass'];  
    }  
  
    if($fname == $dbfname && $pass == $dbpass)  
    {  
    session_start();  
    $_SESSION['sess_user']=$fname;  
  
    /* Redirect browser */  
    header("Location: InsideBing.php");  
    }  
    } else {  
    echo '<script>alert("Invalid id or password!")</script>';  
    }  
  
} else {  
    echo '<script>alert("All fields are required!")</script>';  
}  
}  
?>