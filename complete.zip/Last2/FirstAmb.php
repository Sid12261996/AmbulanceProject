<html>
<head>
  <meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<title>Ambulance</title>
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  	<link href="CSS/First.css" rel="stylesheet" />
</head>
<body id="grad1">

  <div class="modal fade" id="showModal" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
  	<div class="modal-content">
  	<div class="modal-header">
  	<span class="Sup"><h5>SignUp</h5></span>
  	<button type="button" class="close" data-dismiss="modal"  aria-label="Close">
      <span aria-hidden="true">&times;</span>
      </button>
  </div>
  	<form action="" method="post">
  		<div class="modal-body text-center">

  			<table align="center" cellpadding="8px">
            <tr>
              <td>First Name:</td>
              <td><input type="text" name="fname" placeholder="First Name" class="Textbox" id="Fname"></td>
            </tr>

            <tr>
              <td>Last name</td>
              <td><input type="text" name="lname" placeholder="Last Name" class="Textbox"></td>
            </tr>

            <tr>
              <td>Mobile number</td>
              <td><input type="text" name="userPhone" value="" placeholder="10 Digits only" class="Textbox"></td>
            </tr>

            <tr>
              <td>Email</td>
              <td><input type="email" name="email" value="" class="Textbox"></td>
            </tr>

            <tr>
              <td>Password</td>
              <td> <input type="password" name="Pass" value="" class="Textbox"></td>
            </tr>

            <tr>
              <td>Confirm password</td>
              <td><input type="password" name="word" value="" class="Textbox"></td>
            </tr>

            <tr>
              <td colspan="2" rowspan="2"><button type="submit" name="ModButton" class="" id="submitbtn">Sign Up</button></td>
            </tr>
          </table>
  		</div>

  	</form>
  </div>
  </div>
  </div>


<!--Carousel-->
  <div class="carousel-inner">
  		<div class="carousel-item active">
  			<img src="Img/Back.jpg" class="Sky">
  			<div class="carousel-caption">
  			<img src="Img/Plus.png" class="Logo" alt="Plus-Logo">

  			</div>
  		</div>
  	</div>
  <img src="Img/logo.png" alt="" id="logoAnimation">
<!--Form-->
<div class="container-fluid col-md-12 text-center padding">


  <form action="" method="post">
    <table align="center" cellpadding="3px">
      <tr>
        <td>Email ID</td>
        <td><input type="email" name="email" /></td>
      </tr>
      <tr>
        <td>Password</td>
        <td><input type="password" name="pass" /></td>
      </tr>
    </table>
    <div class="signup">
      <h6>New? Sign Up <a href="" data-toggle="modal" data-target="#showModal" >Here</a></h6>
      <button type="submit" name="login" class="btn-success curve">LogIn</button>
    </div>
  </form>

  <h6>Or</h6>
  <button type="button" class="btn curve"><a href="InsideBing.php">Emergency Call</a></button>
</div>
<div class="animation">

</div>
</body>
</html>

<?php  
if(isset($_POST["login"])){  
  
if(!empty($_POST['email']) && !empty($_POST['pass'])) {  
    $email=$_POST['email'];  
    $pass=$_POST['pass'];  
  
    $con=mysql_connect('localhost','root','') or die(mysql_error());  
    mysql_select_db('ambulance') or die("cannot select DB");  
  
    $query=mysql_query("SELECT * FROM ambulanceinfo WHERE email='".$email."' AND pass='".$pass."'");  
    $numrows=mysql_num_rows($query);  
    if($numrows!=0)  
    {  
    while($row=mysql_fetch_assoc($query))  
    {  
    $dbemail=$row['email'];  
    $dbpass=$row['pass'];  
    }  
  
    if($email == $dbemail && $pass == $dbpass)  
    {  
    session_start();  
    $_SESSION['sess_user']=$email;  
  
    /* Redirect browser */  
    header("Location: InsideBing.php");  
    }  
    } else {  
    echo '<script>alert("Invalid email or password!")</script>';  
    }  
  
} else {  
    echo '<script>alert("All fields are required!")</script>';  
}  
}  

if(isset($_POST['ModButton']))
        {
			$fname=$_POST['fname'];
				$lname=$_POST['lname'];
				$userPhone=$_POST['userPhone'];
				$email=$_POST['email'];
				$pass=$_POST['pass'];
				$word=$_POST['word'];
			if(empty($fname) && empty($lname) && empty($userPhone) && empty($email) && empty($pass) && empty($word)) 
			{  
				echo '<script>alert("All fields are required!")</script>';  
			}
			else
			{
				
					$con=mysql_connect('localhost','root','') or die(mysql_error());  
					mysql_select_db('ambulance') or die("cannot select DB");  
					$query="INSERT INTO ambulanceinfo(fname,lname,userPhone,email,pass,word)values('".$fname."','".$lname."','".$userPhone."','".$email."','".$pass."','".$word."')";
					$result=mysql_query($query) or die(mysql_error());
						{
							if($result>0)
							echo'<script>alert("You have successfully signup")</script>';
							
						}
					
			}
			  
                              
		}
?> 
