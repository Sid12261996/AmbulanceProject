<?php
    $fname=$lname=$email=$bdays=$pass=$word=$userPhone=$status="";
    $rfname=$rlname=$remail=$rform=$rbdays=$rpass=$rword=$ruserPhone="";
    if(isset($_GET['signup']) )
        {
            $fname=$_GET['fname'];
            $lname=$_GET['lname'];
            $email=$_GET['email'];
            $bdays=$_GET['bdays'];
			$userPhone=$_GET['userPhone'];
            $pass=$_GET['pass'];
            $word=$_GET['word'];
            $signup=$_GET['signup'];  
            if(empty($fname))
                $rfname="required<br>";
            if(empty($lname))
                $rlname="required<br>";
            if(empty($email))
                $remail="required<br>";
            elseif(!FILTER_VAR($email,FILTER_VALIDATE_EMAIL))
                $remail="INVALID EMAIL.<br>";
            if(empty($bdays))
                $rbdays="required<br>";
			if(empty($userPhone))
                $ruserPhone="required<br>";	
            if(empty($pass))
                $rpass="required<br>";
            if(empty($word))
                $rword="required<br>";
			if($rfname=="" && $rlname=="" && $remail=="" && $rbdays=="" && $ruserPhone=="" && $rpass=="" && $rword=="")
                {
                    include("dataBaseConnect.php");
                    $query="insert into userinfo(fname,lname,email,bdays,userPhone,pass,word)values('".$fname."','".$lname."','".$email."','".$bdays."','".$userPhone."','".$pass."','".$word."')";
                    $result=mysql_query($query) or die(mysql_error());
                    {
                        if($result>0)
                        $status="<br>Hello $fname $lname<br><br> You have completed SignUp.";
                        else
                        $status="SignUp failed";
                    }
                }
        }
?>
<html>
   <head>
    
         <title>sign up</title>
         <link rel="stylesheet" href="CSS/design.css">     
   </head>
   <body>
        <form action="" method="">
            <div class="problem">
			</div>
		
                <div class="style">
                <h3>SIGN UP</h3>
                <label for="fname">First Name:</label>  
                <input type="text" id="fname" name="fname" class="size" size="22" value="<?php echo $fname ?>" >
                <?php echo $rfname ?><br><br>
                <label for="lname">Last Name:</label>
                <input type="text" id="lname" name="lname" class="size" size="22" value="<?php echo $lname ?>">
                <?php echo $rlname ?><br><br>
                <label for="email">Email Address: </label>
                <input type="email" id="email" name="email" class="size" size="27" value="<?php echo $email ?>">
                <?php echo $remail ?><br><br>
                Gender 
                <input type="radio" name="form"  value=""> 
                Female
                <input type="radio" name="form" value="">
                Male                                  
                <br><br>
                <label for="bdays">Date of Birth:</label> &nbsp &nbsp &nbsp &nbsp
                <input type="date" id="bdays" name="bdays" class="size" size="25" value="<?php echo $bdays ?>">
                <?php echo $rbdays ?><br><br>
				
				<label for="userPhone">Phone No:</label> &nbsp &nbsp &nbsp &nbsp
                <input type="number" id="userPhone" name="userPhone" class="size" size="25" value="<?php echo $userPhone ?>">
                <?php echo $ruserPhone ?><br><br>
				
                <label for="pass">User Password: </label> &nbsp &nbsp&nbsp
                <input type="password" id="pass" name="pass" class="size"  size="25" value="<?php echo $pass ?>">
                <?php echo $rpass ?><br><br>
                <label for="word">Confirm Password: </label>
                <input type="password" id="word" name="word" class="size" size="25" value="<?php echo $word ?>">
                <?php echo $rword ?><br><br>
                <input type="SUBMIT" name="signup" class="size" value="SIGN UP" align="center" ><br>
				<?php echo"$status";?>
                </div>
            </div>
        </form>  
           
   </body> 
</html>       