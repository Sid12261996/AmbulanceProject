# AmbulanceProject
A Web application to create a connection between Ambulace drivers and patients in emergency
