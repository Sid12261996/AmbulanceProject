<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ambulance</title>
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  	<script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
  	<link href="CSS/Inside1.css" rel="stylesheet" />
  </head>
  <body id="grad1">

<!--Navbar-->
<nav class="navbar navbar-expand-md bg-light sticky-top">
<div class="container-fluid text-center">
    <div class="navbar-header">
	  <h1 class="navbar-brand">SOS ALLERT!!!</h1>
    </div>
		<button class="btn btn-success my-2 my-sm-2" type="submit" href=""><a href="index.php">Back</a></button>
</div>
</nav>

<!--googleapis-->
<div class="container-fluid frame">
  <iframe src="https://www.google.com"></iframe>
  <!--Instead of Iframme use googleapi part the way you know in php here..remove Iframe-->
  </div>
</div>

  </body>
</html>
